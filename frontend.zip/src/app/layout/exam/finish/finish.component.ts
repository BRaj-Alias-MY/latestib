import { Component, OnInit } from '@angular/core';
import { Pin } from '../../../../pinupdate';
import { AppService } from '../../../app.service';
import { Router } from '@angular/router';
declare var $: any;
@Component({
  selector: 'app-finish',
  templateUrl: './finish.component.html',
  styleUrls: ['./finish.component.css']
})
export class FinishComponent implements OnInit {
  message = 'Thank you..! Your Interview will be reviewd by our experts and will be notified status soon..!';

  mystatus = localStorage.getItem('status');
  pin = localStorage.getItem('pin');
  email = localStorage.getItem('email');
  pinclass: Pin;
  interviewsList = [];
  examstatus = 'Completed';
  currentInterviewId: number;
  myInterviewStatus = localStorage.getItem('myinterviewstatus');

  constructor(private service: AppService, private router: Router) {
    this.pinclass = new Pin();
  }

  ngOnInit() {
    $('#getlink').trigger('click');

    $(document).ready(function () {
      $('#getlink').trigger('click');

    });
    // this.updatePin();
    this.getInterviewsList();
    localStorage.setItem('InterviewId', '');

  }
  getInterviewsList() {
    // alert(this.examstatus);
    this.service.getInterviewsList(this.examstatus, this.email).subscribe(resp => { this.interviewsList = resp; console.log(resp); }, err => console.log(err));
  }


  viewInterview(interviewId) {
    localStorage.setItem('currentInterview', interviewId);
    this.router.navigate(['/examboard/videos']);
  }
  gotoHome() {
    return this.router.navigate(['/examboard/entrypage']);
  }
  viewReview(id) {
    localStorage.setItem('vid', id);
    return this.router.navigate(['/examboard/reviews']);
  }

}
