import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userinterview',
  templateUrl: './userinterview.component.html',
  styleUrls: ['./userinterview.component.css']
})
export class UserinterviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
