export class Feedback {
  id: number;
  review: string;
  rating: string ;
}
